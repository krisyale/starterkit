<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="description" content="<?php echo $meta_desc ?>">
		<meta name="keywords" content="<?php echo $meta_kword ?>">

		<title><?php echo $title ?></title>

		<?php echo $js_redirect ?>
	</head>
	<body>
		<?php echo $content ?>
	</body>
</html>