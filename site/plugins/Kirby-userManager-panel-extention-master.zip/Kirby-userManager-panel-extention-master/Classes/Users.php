<?php
	/**
	 * Created by PhpStorm.
	 * User: lcd34
	 * Date: 9/9/2016
	 * Time: 7:33 PM
	 */

	namespace lcd344;


	class Users extends \Users {

		use ExtendedUsers;
	}
?>