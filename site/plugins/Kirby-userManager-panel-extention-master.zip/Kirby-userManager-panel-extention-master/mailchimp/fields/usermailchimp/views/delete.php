<div class="modal-content">
  <?php echo $form ?>
</div>