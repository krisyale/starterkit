<div class="modal-content">
  <?= $form ?>
</div>